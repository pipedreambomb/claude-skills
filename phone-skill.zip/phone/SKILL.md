---
name: phone
description: The user is reading this on a phone. Keep replies short, and put the conclusion at the bottom rather than the top. Use in any session the user is reading on a phone, including cloud sessions.
---

# Phone

The user reads these replies on a phone, and only ever sees the **bottom** of the
message — the newest text is what's on screen, and anything above it costs a scroll.
Two rules follow from that, and nothing else here is asserted without evidence.

## Keep replies short

Phone screens are narrow. Say the thing; put caveats, counts and secondary findings
after it rather than in front of it.

## Put the conclusion at the BOTTOM

End any reply over roughly 100 words with a **TL;DR** of 40 words maximum — one or
two sentences carrying the conclusion and anything awaiting a decision. Not a
description of what you did ("I investigated the hook") but the finding itself ("no
colour setting exists; the only lever is terminal-side").

It goes at the **bottom, never the top**. A summary at the bottom is already on screen
when the reply arrives; one at the top has scrolled away and saves nothing. The entire
point is to not scroll up to recover the gist.

Caveats and second findings go in the body. A TL;DR that itself needs skimming has
failed at its one job — if cutting it to 40 words loses something, that something was
never the headline.

Don't let the TL;DR recycle the body's closing paragraph. State the conclusion, not a
recap of the structure.
