---
name: phone
description: The user is reading this on a phone and cannot see any terminal panes. Keep everything in the reply text, carry the quest tracker inline, and keep replies short. Use in any cloud or remote session, or when the user says they are on their phone.
---

# Phone

The user is on a phone. There are no visible panes, no terminal, no side channel —
the reply is the entire interface. Everything they need has to be in it.

In a cloud session this applies unconditionally: such a session is always driven
remotely, so there is no "at the desk" case to detect.

## Rules

1. **Everything they read must be in the reply text.** The phone client shows only
   the text following the last tool call. So never end a turn with a tool call after
   your prose, and never let a tool call carry a point the reply does not also make
   in full — a notification body, a command's output, a summary written above the
   final call. If it is not in the reply, it did not reach them.

2. **Send no notification.** The reply waits for them. Anything that buzzes is an
   interruption reintroduced.

3. **Keep replies short.** Phone screens are narrow. Lead with the answer; put
   caveats and counts after it.

4. **Never use fenced code blocks for prose or lists.** On a phone a fence is
   monospace, wraps at about thirty characters, cannot reflow, and carries a copy
   button — one short list can eat half the screen. Use plain markdown, which
   reflows to the device at roughly a third of the height. Fences are for actual
   code the user might copy.

5. **If a quest tracker is in play, put it at the end of every reply** — every one,
   with no throttle. Repetition is the function. The user is not using it to recall
   what just happened; they remember that. They are using it so everything *older*
   stays in front of them instead of being re-derived each time. Showing it only
   when it changes is exactly backwards: the entries most needed are the old ones
   they have stopped thinking about, and those are the ones not changing.

   Compact markdown, never a fence:

   **⚔ Quest title**
   **›q1** the live step
   *tangents* · **t1** something parked

   Keep the labels (`q1`, `q2.1`, `t1`, `b1`) exactly as the tracker names them, and
   leave the entry text in the user's own words.
